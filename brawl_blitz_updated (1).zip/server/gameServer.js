const io = require("socket.io")(3001,{cors:{origin:"*"}})

let players = {}

io.on("connection",(socket)=>{
  players[socket.id] = {x:400,y:300,hp:100}
  socket.emit("currentPlayers",players)

  socket.broadcast.emit("newPlayer",{id:socket.id,...players[socket.id]})

  socket.on("playerMove",(data)=>{
    if(!players[socket.id]) return
    players[socket.id].x=data.x
    players[socket.id].y=data.y

    socket.broadcast.emit("playerMoved",{
      id:socket.id,
      x:data.x,
      y:data.y
    })
  })

  socket.on("disconnect",()=>{
    delete players[socket.id]
    io.emit("playerDisconnected",socket.id)
  })
})
