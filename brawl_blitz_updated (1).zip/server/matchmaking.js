let rooms = []

function findRoom(){
  let room = rooms.find(r=>r.players.length < 6)
  if(!room){
    room = {id:Date.now(),players:[]}
    rooms.push(room)
  }
  return room
}

function joinMatch(playerId){
  const room = findRoom()
  room.players.push(playerId)
  return room.id
}

module.exports = { joinMatch }
