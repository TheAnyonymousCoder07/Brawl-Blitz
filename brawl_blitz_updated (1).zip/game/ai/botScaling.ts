export function getBotStats(playerLevel:number){
  const difficulty = Math.min(1 + playerLevel * 0.1,5)

  return {
    health:100 * difficulty,
    damage:10 * difficulty,
    speed:1 + difficulty*0.1
  }
}
